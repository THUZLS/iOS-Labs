//
//  ViewController.m
//  Hello_World_Improve
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "ViewController.h"
#import "helloworld.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn3;
@property (weak, nonatomic) IBOutlet UITextField *text1;
@property (weak, nonatomic) IBOutlet UILabel *label1;

@end

@implementation ViewController
- (IBAction)sayhello1:(UIButton *)sender {
    self.label1.text=[helloworld sayHelloWorld];
}
- (IBAction)sayhello2:(UIButton *)sender {
    helloworld *h=[[helloworld alloc]init];
    self.label1.text=[h sayhello:@"IOS world"];
}
- (IBAction)sayhello3:(UIButton *)sender {
    helloworld *h=[[helloworld alloc]init];
    h.something=self.text1.text;
    self.label1.text=[h saySomething];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if(textField==self.text1)
    {
        [textField resignFirstResponder];
    }
    return YES;
}
@end
