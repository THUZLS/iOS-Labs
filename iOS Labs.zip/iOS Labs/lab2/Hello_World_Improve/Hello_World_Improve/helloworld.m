//
//  helloworld.m
//  Hello_World_Improve
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "helloworld.h"

@implementation helloworld
@synthesize something=_something;
-(void)setSomething:(NSString *)something
{
    NSMutableString *mstr=[NSMutableString stringWithString:something];
    [mstr appendString:@"😁"];
    _something=mstr;
}
-(NSString *)something
{
    return _something;
}

+(NSString*)sayHelloWorld
{
    return @"Hello World";
}

-(NSString*)sayhello:(NSString*)greeting
{
    NSString *str=@"Hello ";
    NSMutableString *mstr=[NSMutableString stringWithString:str];
    [mstr appendString:greeting];
    return mstr;
}

-(NSString*)saySomething
{
    NSString *str=@"Hello ";
    NSMutableString *mstr=[NSMutableString stringWithString:str];
    [mstr appendString:self.something];
    return mstr;
    
}

@end

