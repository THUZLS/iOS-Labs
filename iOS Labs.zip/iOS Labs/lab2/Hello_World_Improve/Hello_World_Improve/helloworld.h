//
//  helloworld.h
//  Hello_World_Improve
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface helloworld : NSObject
@property(strong,nonatomic)NSString *something;
+(NSString*)sayHelloWorld;
-(NSString*)sayhello:(NSString*)greeting;
-(NSString*)saySomething;
@end

