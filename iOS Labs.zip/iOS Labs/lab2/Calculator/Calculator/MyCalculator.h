//
//  MyCalculator.h
//  Calculator
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCalculator : NSObject
@property(strong,nonatomic)NSMutableString *disp;
-(void) delNumber;
-(NSString *)computerResult;
-(void)cleardisp;

@end
