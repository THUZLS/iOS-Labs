//
//  AppDelegate.h
//  Calculator
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

