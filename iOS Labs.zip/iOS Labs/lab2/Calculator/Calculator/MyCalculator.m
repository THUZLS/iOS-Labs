//
//  MyCalculator.m
//  Calculator
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "MyCalculator.h"

@implementation MyCalculator

-(void)cleardisp
{
    self.disp=nil;
}

-(NSMutableString *)disp
{
    if(!_disp)
    {
        _disp=[[NSMutableString alloc]init];
    }
    return _disp;
}

-(void) delNumber
{
    long len=self.disp.length-1;
    if(len>=0)
    {
        [self.disp deleteCharactersInRange:NSMakeRange(len, 1)];
    }
}

-(NSString *)computerResult
{
    @try {
        NSExpression *expl=[NSExpression expressionWithFormat:self.disp];
        id value=[expl expressionValueWithObject:nil context:nil];
        NSLog(@"result=%f",[value floatValue]);
        self.disp=[NSMutableString stringWithString:[value stringValue]];
        return [value stringValue];
    }
    @catch (NSException *exception) {
        self.disp=nil;
        return @"error";
    }
}


@end
