//
//  UIViewControl.m
//  multiViewApp
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "UIViewControl.h"

@implementation UIViewControl

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)drawRect:(CGRect)rect
{
    UIBezierPath *path = [[UIBezierPath alloc] init];
    [path moveToPoint:CGPointMake(32, 295)];
    [path addLineToPoint:CGPointMake(342, 295)];
    [path addLineToPoint:CGPointMake(342, 372)];
    [path addLineToPoint:CGPointMake(32, 372)];
    [path closePath];
    //考虑直接画一个矩形
    [[UIColor grayColor] setStroke];
    [path stroke];
}

@end
