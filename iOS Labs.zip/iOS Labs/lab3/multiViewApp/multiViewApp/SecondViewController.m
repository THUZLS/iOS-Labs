//
//  SecondViewController.m
//  multiViewApp
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtdisp;
@property (weak, nonatomic) IBOutlet UIButton *buttonleft;
@property (weak, nonatomic) IBOutlet UIButton *buttonright;
@property (weak, nonatomic) IBOutlet UIButton *buttone;
@property (weak, nonatomic) IBOutlet UIButton *buttonpi;

@end

@implementation SecondViewController
- (IBAction)input:(UIButton *)sender {
    if(sender.tag==0||sender.tag==1||sender.tag==2||sender.tag==3){
        if([[[sender titleLabel]text] isEqualToString:@"e"]){
            [self.calculator.input appendString:@"2.7182818"];
        }else if([[[sender titleLabel]text] isEqualToString:@"pi"]){
            [self.calculator.input appendString:@"3.1415926"];
        }else{
            [self.calculator.input appendString:[[sender titleLabel]text]];
        }
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        [str appendString:[[sender titleLabel] text]];
        self.txtdisp.text=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==4){
        self.txtdisp.text=[self.calculator abs:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==5){
        self.txtdisp.text=[self.calculator sqrt:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==6){
        self.txtdisp.text=[self.calculator reciprocal:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==7){
        self.txtdisp.text=[self.calculator pow2:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==8){
        self.txtdisp.text=[self.calculator sin:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==9){
        self.txtdisp.text=[self.calculator cos:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==10){
        self.txtdisp.text=[self.calculator tan:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==11){
        self.txtdisp.text=[self.calculator pow3:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==12){
        self.txtdisp.text=[self.calculator arcsin:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==13){
        self.txtdisp.text=[self.calculator arccos:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==14){
        self.txtdisp.text=[self.calculator arctan:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==15){
        self.txtdisp.text=[self.calculator log10:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==16){
        self.txtdisp.text=[self.calculator sinh:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==17){
        self.txtdisp.text=[self.calculator cosh:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==18){
        self.txtdisp.text=[self.calculator tanh:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }else if(sender.tag==19){
        self.txtdisp.text=[self.calculator log10:self.calculator.input];
        NSMutableString *str=[NSMutableString stringWithString:self.txtdisp.text];
        self.calculator.input=str;
        self.calculator.screen=str;
        
    }
}

-(void)viewWillAppear:(BOOL)animated{
    //将视图刚要显示的时候，将传递过来的内容在屏幕中显示
    self.txtdisp.text=self.calculator.screen;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
