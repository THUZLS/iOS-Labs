//
//  ViewController.m
//  multiViewApp
//
//  Created by mac  on 2016/12/29.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "ViewController.h"
#import "advancedCalculator.h"
#import "SecondViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtdisp;
@property (weak, nonatomic) IBOutlet UIButton *button1;
@property (weak, nonatomic) IBOutlet UIButton *button2;
@property (weak, nonatomic) IBOutlet UIButton *button3;
@property (weak, nonatomic) IBOutlet UIButton *button4;
@property (weak, nonatomic) IBOutlet UIButton *button5;
@property (weak, nonatomic) IBOutlet UIButton *button6;
@property (weak, nonatomic) IBOutlet UIButton *button7;
@property (weak, nonatomic) IBOutlet UIButton *button8;
@property (weak, nonatomic) IBOutlet UIButton *button9;
@property (weak, nonatomic) IBOutlet UIButton *button0;
@property (weak, nonatomic) IBOutlet UIButton *buttondot;
@property (weak, nonatomic) IBOutlet UIButton *buttondiv;
@property (weak, nonatomic) IBOutlet UIButton *buttonmul;
@property (weak, nonatomic) IBOutlet UIButton *buttonsub;
@property (weak, nonatomic) IBOutlet UIButton *buttonadd;
@property (strong,nonatomic) advancedCalculator *cal;

@end

@implementation ViewController

- (advancedCalculator *)cal{
    if(!_cal){
        _cal=[[advancedCalculator alloc]init];
    }
    return _cal;
}

- (IBAction)calculate:(UIButton *)sender {
    if([self.txtdisp.text length]==0){
        self.txtdisp.text=@"Error input!";
        return;
    }
    
    NSMutableString *calculateResult=[NSMutableString stringWithString:self.cal.input];
    [calculateResult appendString:[[sender titleLabel] text]];
    self.txtdisp.text=[self.cal ExpressionCalculate:calculateResult];
    NSMutableString *tempStr=[NSMutableString stringWithString:self.txtdisp.text];;
    self.cal.screen = tempStr;

}

- (IBAction)delonechara:(UIButton *)sender {
    NSInteger length=[self.cal.input length];
    if(length>0){
        [self.cal.input deleteCharactersInRange:NSMakeRange(length-1, 1)];
        //一定也要对输入框中的表达式进行处理，因为input里面的× ÷和显示的* /不同
        NSMutableString *delResultString=[NSMutableString stringWithString:self.txtdisp.text];
        [delResultString deleteCharactersInRange:NSMakeRange(length-1, 1)];
        NSLog(@"deleteResult=%@",self.cal.input);
        self.cal.screen=delResultString;
        self.txtdisp.text=delResultString;
    }
}

- (IBAction)clear:(UIButton *)sender {
    self.txtdisp.text=nil;
    [self.cal clearAll];
}

- (IBAction)input:(UIButton *)sender {
    if([[[sender titleLabel] text] isEqualToString:@"×"]){
        [self.cal.input appendString:@"*"];
    }else if([[[sender titleLabel] text] isEqualToString:@"÷"]){
        [self.cal.input appendString:@"/"];
    }else{
        [self.cal.input appendString:[[sender titleLabel] text]];
    }
    NSMutableString *originalString=[NSMutableString stringWithString:self.txtdisp.text];
    [originalString appendString:[[sender titleLabel] text]];
    NSInteger length=[originalString length];
    if(length >= 30)
        [originalString deleteCharactersInRange:NSMakeRange(0, length-30)];
    self.txtdisp.text=originalString;
    self.cal.screen=originalString;
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"SecondScene"]){
        if([segue.destinationViewController isKindOfClass:[SecondViewController class]]){
            SecondViewController *svc=(SecondViewController *)segue.destinationViewController;
            svc.calculator=self.cal;
        }
    }
}

-(void)viewWillAppear:(BOOL)animated{
    self.txtdisp.text=self.cal.screen;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.cal=[[advancedCalculator alloc] init];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
