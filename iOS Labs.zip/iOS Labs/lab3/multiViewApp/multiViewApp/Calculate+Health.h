//
//  Calculate+Health.h
//  multiViewApp
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "Calculate.h"

@interface Calculate (Health)
-(NSString *)computeHealthWithHeight:(NSString *)height andWeight:(NSString *)weight;
@end
