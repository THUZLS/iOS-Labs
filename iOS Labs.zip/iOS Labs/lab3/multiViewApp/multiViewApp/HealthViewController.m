//
//  HealthViewController.m
//  multiViewApp
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "HealthViewController.h"
#import "Calculate+Health.h"

@interface HealthViewController ()
@property (weak, nonatomic) IBOutlet UILabel *labelAdvice;
@property (weak, nonatomic) IBOutlet UILabel *labelScore;
@property (weak, nonatomic) IBOutlet UIButton *btnCalculate;
@property (weak, nonatomic) IBOutlet UITextField *Txtheight;
@property (weak, nonatomic) IBOutlet UITextField *Txtweight;
@property (strong,nonatomic) Calculate *calculator;
@end

@implementation HealthViewController
- (IBAction)CompuateScore:(UIButton *)sender {
    NSString *score =[self.calculator computeHealthWithHeight:self.Txtheight.text andWeight:self.Txtweight.text];
    if ([score floatValue] < 19)
        self.labelAdvice.text = @"建议：太瘦了，多吃点东西";
    else if([score floatValue] < 25)
        self.labelAdvice.text = @"建议：完美身材100分";
    else if([score floatValue] < 30)
        self.labelAdvice.text = @"建议：你有变胖的趋势";
    else if([score floatValue] < 39)
        self.labelAdvice.text = @"快锻炼吧，体重亮红灯亮";
    else
        self.labelAdvice.text = @"地球快要承载不住你了";
    
    NSString *cuestr = @"体重指数：";
    NSMutableString *tempstr = [NSMutableString stringWithString:cuestr];
    [tempstr appendString:score];
    self.labelScore.text = tempstr;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField==self.Txtheight||textField==self.Txtweight){
        [textField resignFirstResponder];
    }
    return YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [self.btnCalculate.layer setMasksToBounds:YES];
    [self.btnCalculate.layer setCornerRadius:12];
    [self.btnCalculate.layer setBorderWidth:1];
    //    [self.btnCalculate.layer setBorderColor:NULL];
}

-(Calculate *)calculator{
    if(!_calculator){
        _calculator=[[Calculate alloc]init];
    }
    return _calculator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.calculator=[[Calculate alloc]init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
