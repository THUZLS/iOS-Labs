//
//  Student.m
//  StudentScore
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "Student.h"

@implementation Student
-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.number forKey:@"number"];
    [aCoder encodeInteger:self.age forKey:@"age"];
    [aCoder encodeFloat:self.score forKey:@"score"];
    [aCoder encodeObject:self.teacher forKey:@"teacher"];
    [aCoder encodeObject:self.remark forKey:@"remark"];
    
}
-(id)initWithCoder:(NSCoder *)aDecoder
{
    if(self=[super init])
    {
        self.name= [aDecoder decodeObjectForKey:@"name"];
        self.number= [aDecoder decodeObjectForKey:@"number"];
        self.age=[aDecoder decodeIntegerForKey:@"age"];
        self.score=[aDecoder decodeFloatForKey:@"score"];
        self.remark=[aDecoder decodeObjectForKey:@"remark"];
        self.teacher=[aDecoder decodeObjectForKey:@"teacher"];
        
        
    }
    
    return self;
}

@end
