//
//  ViewController.m
//  StudentScore
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"
#import "TableViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtname;
@property (weak, nonatomic) IBOutlet UITextField *txtnumber;
@property (weak, nonatomic) IBOutlet UITextField *txtage;
@property (weak, nonatomic) IBOutlet UITextField *txtscore;
@property (weak, nonatomic) IBOutlet UITextField *txtremark;

@end

@implementation ViewController
- (IBAction)DataSave:(UIButton *)sender {
    int contorlNum0=0;
    
    NSString * regex4        = @"^\\d+(.\\d)?$";
    NSPredicate * pred4      = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex4];
    //BOOL isMatch            = [pred3 evaluateWithObject:self.txtage.text];
    
    if (![pred4 evaluateWithObject: self.txtscore.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"成绩请输入0～100内的数字(最多一位小数)！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        contorlNum0=1;
        //        return;
    }
    else if([self.txtscore.text intValue]>100||[self.txtscore.text intValue]<0)
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"年龄请输入0～100内的数字(最多一位小数)！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        contorlNum0=1;
        //        return;
    }
    
    
    NSString * regex3        = @"^[0-9]{1,3}$";
    NSPredicate * pred3      = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex3];
    //BOOL isMatch            = [pred3 evaluateWithObject:self.txtage.text];
    
    if (![pred3 evaluateWithObject: self.txtage.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"年龄请输入0～130内的整数！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        contorlNum0=1;
        //        return;
        
    }
    else if([self.txtage.text intValue]>130||[self.txtage.text intValue]<0)
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"年龄请输入0～130内的整数！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        contorlNum0=1;
        //        return;
    }
    
    NSString *regex2 = @"^[A-Za-z0-9]{9,15}$";
    NSPredicate *pred2 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex2];
    if(![pred2 evaluateWithObject: self.txtnumber.text])
    {
        
        ////此动画为弹出buttonqww
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"学号只能由9—15位字母或数字组成" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        contorlNum0=1;
        //        return;
    }
    
    NSString *regex = @"[a-zA-Z\u4e00-\u9fa5][a-zA  -Z0-9\u4e00-\u9fa5]+";//@"[\u4e00-\u9fa5]";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    if(![pred evaluateWithObject: self.txtname.text])
    {
        
        ////此动画为弹出buttonqww
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"昵称只能由中文、字母或数字组成" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        contorlNum0=1;
        //        return;
    }
    
    if (contorlNum0==1) {
        return;
    }
    
    TableViewController *tc=[[TableViewController alloc]init];
    Student *student=[[Student alloc]init];
    student.name=self.txtname.text;
    student.number=self.txtnumber.text;
    student.age=[self.txtage.text floatValue];
    student.score=[self.txtscore.text floatValue];
    student.remark=self.txtremark.text;
    student.teacher=@"dai night";
    
    if(self.indexPath==nil)
    {
        [self.students addObject:student];
        [tc writeToFile:self.students filePath:self.path ];
        
    }
    else
    {
        //self.students[self.indexPath.row]=student;
        self.students[self.indexPath.row]=student;
        [tc writeToFile:self.students filePath:self.path ];
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)datacancel:(UIButton *)sender {
    self.txtname.text=nil;
    self.txtnumber.text=nil;
    self.txtage.text=nil;
    self.txtscore.text=nil;
    self.txtremark.text=nil;
}

-(void)viewWillAppear:(BOOL)animated
{
    if(self.indexPath!=nil)
    {
        Student *student=self.students[self.indexPath.row];
        self.txtname.text=student.name;
        self.txtnumber.text=student.number;
        self.txtage.text=[NSString stringWithFormat:@"%ld",student.age];
        self.txtscore.text=[NSString stringWithFormat:@"%f",student.score];
        self.txtremark.text=student.remark;
    }
    
}

+ (void)isNumText:(NSString *)str{
    NSString * regex        = @"(/^[0-9]*$/)";
    NSPredicate * pred      = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch            = [pred evaluateWithObject:str];
    if (isMatch&&(int)str>=0&&(int)str<=120)
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请输入正确的年龄！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if((textField==self.txtname) || (textField==self.txtnumber) || (textField==self.txtage) || (textField==self.txtscore) || (textField==self.txtremark) )
    {
        [textField resignFirstResponder];
    }
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];   //触摸空白背景收起键盘
}

@end
