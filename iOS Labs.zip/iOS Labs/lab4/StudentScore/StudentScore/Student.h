//
//  Student.h
//  StudentScore
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject<NSCoding>
@property(strong,nonatomic)NSString* name;
@property(strong,nonatomic)NSString* number;
@property(nonatomic)NSInteger age;
@property(nonatomic)float score;
@property(strong,nonatomic)NSString* remark;
@property(strong,nonatomic)NSString* teacher;

@end
