//
//  Student.m
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import "Student.h"
#import "Teacher.h"


@implementation Student

@dynamic age;
@dynamic memo;
@dynamic name;
@dynamic number;
@dynamic score;
@dynamic whoTeach;

@end
