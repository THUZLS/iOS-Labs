//
//  ViewController.m
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//


#import "ViewController.h"
#import "Student.h"
#import "TableViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *TxtName;
@property (weak, nonatomic) IBOutlet UITextField *TxtNumber;
@property (weak, nonatomic) IBOutlet UITextField *TxtAge;
@property (weak, nonatomic) IBOutlet UITextField *TxtScore;
@property (weak, nonatomic) IBOutlet UITextField *TxtTeacher;
@property (weak, nonatomic) IBOutlet UITextView *TxtMemo;

@end

@implementation ViewController

- (IBAction)DataClear:(UIButton *)sender {
    self.TxtName.text=nil;
    self.TxtNumber.text=nil;
    self.TxtAge.text=nil;
    self.TxtMemo.text=nil;
    self.TxtScore.text=nil;
    self.TxtTeacher.text=nil;
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)DataSave:(UIButton *)sender {
    NSScanner *scan1=[NSScanner scannerWithString:self.TxtName.text];
    NSScanner *scan2=[NSScanner scannerWithString:self.TxtScore.text];
    if ([scan1 scanInteger:nil] || !([scan2 scanFloat:nil] && [scan2 isAtEnd])) {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Wrong Type!" message:@"Name shouldn't include numbers;       Score must be a float value!" delegate:nil cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
        [alert show];
    }
    else {
    
    Student *stu;
    if (self.indexPath==nil) {

        stu=[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:self.context];
        [self.students addObject:stu];
    }else
        stu=self.students[self.indexPath.row];
    
        stu.name=self.TxtName.text;
        stu.number=self.TxtNumber.text;
        stu.age=[NSNumber numberWithFloat:[self.TxtAge.text floatValue]];
        stu.score=[NSNumber numberWithFloat:[self.TxtScore.text floatValue]];
        stu.memo=self.TxtMemo.text;
        stu.whoTeach=self.teacher;
    
        NSError *errorstudent;
        //NSManagedObjectContext对象的save方法保存变化了的数据至持久层
        if(![self.context save:&errorstudent])
            NSLog(@"保存时出错：%@",errorstudent);
    
    [self.navigationController popToRootViewControllerAnimated:YES];
        
    }
}

-(void)viewWillAppear:(BOOL)animated{
    if(self.indexPath!=nil){
        Student *student=self.students[self.indexPath.row];
        self.TxtName.text=student.name;
        self.TxtNumber.text=student.number;
        self.TxtAge.text=[NSString stringWithFormat:@"%@",[student.age stringValue]];
        self.TxtScore.text=[NSString stringWithFormat:@"%@",[student.score stringValue]];
        self.TxtMemo.text=student.memo;
        self.TxtTeacher.text=student.whoTeach.name;
    }
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
}
@end
