//
//  TableViewController.m
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//


#import "TableViewController.h"
#import "Student.h"
#import "Teacher.h"
#import "AppDelegate.h"
#import "ViewController.h"

@interface TableViewController ()
@property(strong,nonatomic)NSManagedObjectContext *context;
@property(strong,nonatomic)NSMutableArray *students;
@property(strong,nonatomic)Student *student;
@property(strong,nonatomic)Teacher *teacher;

@end

@implementation TableViewController

- (IBAction)refreshData:(UIRefreshControl *)sender {
    [self.refreshControl beginRefreshing];
    dispatch_queue_t queue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
        [self.students removeAllObjects];
        [self viewDidLoad];
        dispatch_async(dispatch_get_main_queue(),^{[self.tableView reloadData];});
    });
    [self.refreshControl endRefreshing];
}

-(NSManagedObjectContext *)context{
    if(!_context){
        //实例化NSManagedObjectContext对象
        AppDelegate *coreDataManager=[[AppDelegate alloc]init];
        _context=[coreDataManager managedObjectContext];
    }
    return _context;
}

//通过NSFetchRequest对象向持久层取数据
-(NSArray *)queryData:(NSString *)entityname sortWith:(NSString *)sortDesc ascending:(BOOL)asc predicatString:(NSString *)ps
{
    NSFetchRequest *request=[[NSFetchRequest alloc]init];
    request.fetchLimit=100;         //取记录数量上限
    request.fetchBatchSize=20;      //缓存数量上限
    
    //NSFetchRequest对象的sortDescriptors属性对获得的数据进行排序
    request.sortDescriptors=@[[NSSortDescriptor sortDescriptorWithKey:sortDesc ascending:asc]];
    if(ps)
        //NSFetchRequest对象的predicate属性对数据对象进行筛选
        request.predicate=[NSPredicate predicateWithFormat:@"name contains %@",ps];
        //NSEntityDescription对象用来从数据模型中获得实体
        NSEntityDescription *entity=[NSEntityDescription entityForName:entityname inManagedObjectContext:self.context];
        //NSFetchRequest对象的entity属性指出想要获取的实体对象
        request.entity=entity;
        NSError *error;
        //NSManagedObjectContext对象的executeFetchRequest方法向持久层请求数据
        NSArray *arrs=[self.context executeFetchRequest:request error:&error];
        if(error)
            NSLog(@"无法获取数据，%@",error);
        return arrs;
}
/*
-(void)loadData{
    NSArray *arrs=[self queryData:@"Student" sortWith:@"number" ascending:YES predicatString:nil];
    for (Student *stu in arrs) {
        [_students addObject:stu];
    }
}

-(NSMutableArray *)students{
    if(!_students)
        [self loadData];
    return _students;
}
*/
-(Teacher *)teacher{
    if(!_teacher){
        NSArray *arrteacher=[self queryData:@"Teacher" sortWith:@"name" ascending:YES predicatString:@"Bai Tian"];
        if(arrteacher.count>0){
            _teacher=arrteacher[0];
        }else{
            NSError *error;
            Teacher *th=[NSEntityDescription insertNewObjectForEntityForName:@"Teacher" inManagedObjectContext:self.context];
            th.name=@"Bai Tian";
            th.age=[NSNumber numberWithInt:35];
            th.number=@"ST00001";
            [self.context save:&error];
            _teacher=th;
        }
    }
    return _teacher;
}

-(void)viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"addinfo"]) {
        if ([segue.destinationViewController isKindOfClass:[ViewController class]]) {
            ViewController *vc=(ViewController *)segue.destinationViewController;
            vc.students=self.students;
            vc.context=self.context;
            vc.indexPath=nil;
            vc.teacher=self.teacher;
        }
    }
    if([segue.identifier isEqualToString:@"showdetail"]){
        if([segue.destinationViewController isKindOfClass:[ViewController class]]){
            NSIndexPath *indexPath=[self.tableView indexPathForCell:sender];
            ViewController *vc=(ViewController *)segue.destinationViewController;
            vc.students=self.students;
            vc.context=self.context;
            vc.indexPath=indexPath;
            vc.teacher=self.teacher;
        }
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.students count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"studentCell" forIndexPath:indexPath];
    self.student=self.students[indexPath.row];
    cell.textLabel.text=self.student.name;
    cell.detailTextLabel.text=self.student.number;
    return cell;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if(editingStyle ==UITableViewCellEditingStyleDelete){
        //NSManagedObjectContext对象的deleteObject方法删除一个数据对象
        [self.context deleteObject:self.students[indexPath.row]];
        [self.students removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        NSError *error;
        [self.context save:&error];
    }
}

-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    ViewController *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"modifyview"];
    vc.students=self.students;
    vc.indexPath=indexPath;
    vc.context=self.context;
    vc.teacher=self.teacher;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Searchbar Coding
-(void)searchInName:(NSString *)searchString{
    [self.students removeAllObjects];
    NSArray *arrstudents=[self queryData:@"Student" sortWith:@"name" ascending:YES predicatString:searchString];
    for (Student *stu in arrstudents) {
        [self.students addObject:stu];
    }
    [self.tableView reloadData];
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if(searchText.length==0){
        return ;
    }
    [self searchInName:searchText];
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [self searchInName:searchBar.text];
    [searchBar resignFirstResponder];
}

-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [self searchInName:nil];
    [searchBar resignFirstResponder];
    searchBar.text=nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *arrs=[self queryData:@"Student" sortWith:@"number" ascending:YES predicatString:nil];
    self.students=[NSMutableArray arrayWithArray:arrs];
}

@end
