//
//  Teacher.m
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//


#import "Teacher.h"
#import "Student.h"


@implementation Teacher

@dynamic age;
@dynamic name;
@dynamic number;
@dynamic students;

@end
