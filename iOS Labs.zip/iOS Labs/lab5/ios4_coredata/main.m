//
//  main.m
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
