//
//  Student.h
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Teacher;

@interface Student : NSManagedObject

@property (nonatomic, retain) NSNumber * age;
@property (nonatomic, retain) NSString * memo;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * number;
@property (nonatomic, retain) NSNumber * score;
@property (nonatomic, retain) Teacher *whoTeach;

@end
