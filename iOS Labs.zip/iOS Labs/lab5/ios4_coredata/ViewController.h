//
//  ViewController.h
//  实验五
//
//  Created by mac  on 2016/12/30.
//  Copyright © 2016年 张玲松. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "Teacher.h"

@interface ViewController : UIViewController
@property(strong,nonatomic)NSMutableArray *students;
@property(strong,nonatomic)Teacher *teacher;
@property(strong,nonatomic)NSIndexPath *indexPath;
@property(strong,nonatomic)NSManagedObjectContext *context;

@end

