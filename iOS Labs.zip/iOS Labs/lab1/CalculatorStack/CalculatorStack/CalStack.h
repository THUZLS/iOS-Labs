//
//  CalStack.h
//  CalculatorStack
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 mac . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CalStack : NSObject

//参数
extern NSUInteger const size;         //栈最大容量（常量）
@property(nonatomic, retain) NSMutableArray *stackArray;    //栈内元素
@property(nonatomic, retain) NSString *top;                    //栈顶元素

//带参数的构造方法
-(instancetype)initWithSize:(NSUInteger) size;
//获取栈顶元素
-(NSString*)getTop;
//入栈
-(BOOL)push:(NSString*) element;
//出栈
-(NSString*)pop;

@end

