//
//  main.m
//  CalculatorStack
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 mac . All rights reserved.
//

/*实验1.2：利用栈实现数学表达式求值
 具体内容:利用 Object C 和 Foundation 框架,利用栈实现数值表达式的求值。(要求不使用 NSExpression)。
 例如:输入字符串: 10÷6×7+15-8 给出正确的计算值。或输出"字符串不是数学表达式无法计算"。
 */

#import <Foundation/Foundation.h>
#include "Calculator.h"

int main(int argc, const char * argv[]) {
    //输入表达式
    NSString *inputExps = @"10/6*7+15-8";
    NSLog(@"表达式：%@",inputExps);
    
    //使用自定义的堆栈实现运算结果
    Calculator *calculator = [[Calculator alloc]init];
    NSString *result = [calculator ExpressionCalculate:inputExps];
    NSLog(@"堆栈实现的运算结果：%@",result);
    
    //使用NSExpression验证结果
    NSExpression *expression = [NSExpression expressionWithFormat:inputExps];
    id result2 = [expression expressionValueWithObject:nil context:nil];
    [NSString stringWithFormat:@"%@",result2];
    NSLog(@"使用NSExpression验证结果：%@",result2);
    return 0;
}
