//
//  helloworld.h
//  HelloWorld
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 mac . All rights reserved.
//

#import <Foundation/Foundation.h>


@interface helloworld : NSObject

@property(strong, nonatomic) NSString *something;

+ (void)sayHelloWorld;

- (void)sayHello:(NSString *)greeting;

- (void)saysomethong;

@end
