//
//  helloworld.m
//  HelloWorld
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 mac . All rights reserved.
//

#import "helloworld.h"

@interface helloworld () {
}
@end

@implementation helloworld {
    
}
@synthesize something = _something;

- (void)setSomething:(NSString *)something {
    NSMutableString *mstr = [NSMutableString stringWithString:something];
    [mstr appendString:@"😁"];
    _something = mstr;
}

- (NSString *)something {
    return _something;
}

+ (void)sayHelloWorld {
    NSLog(@"Hello World");
}

- (void)sayHello:(NSString *)greeting {
    NSString *str = @"Hello ";
    NSMutableString *mstr = [NSMutableString stringWithString:str];
    [mstr appendString:greeting];
    NSLog(@"%@", mstr);
    
}

- (void)saysomethong {
    NSString *str = @"Hello ";
    NSMutableString *mstr = [NSMutableString stringWithString:str];
    [mstr appendString:self.something];
    NSLog(@"%@", mstr);
}


@end
