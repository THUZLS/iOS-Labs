//
//  main.m
//  HelloWorld
//
//  Created by mac  on 2016/12/28.
//  Copyright © 2016年 mac . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "helloworld.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        [helloworld sayHelloWorld];
        helloworld *h=[[helloworld alloc] init];
        h.something=@"IOS World";
        [h sayHello:@"IOS"];
        [h saysomethong];
    }
    return 0;
}
